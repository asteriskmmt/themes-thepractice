<footer>
    <div class="container">
        <?php tfuse_footer(); ?>

        <div class="divider_space_thin"></div>

        <?php tfuse_social_footer(); ?>

        <div class="copyright">
            <?php echo tfuse_options('custom_copyright');?>
        </div>

    </div>
</footer>

</div>
<?php wp_footer(); ?>
</body>
</html>
