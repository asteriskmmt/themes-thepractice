<?php

/* ----------------------------------------------------------------------------------- */
/* Initializes all the theme settings option fields for categories area.             */
/* ----------------------------------------------------------------------------------- */

$options = array(
    // Element of Hedear
    array('name' => __('Element of Hedear', 'tfuse'),
        'desc' => __('Select type of element on the header.', 'tfuse'),
        'id' => TF_THEME_PREFIX . '_header_element',
        'value' => 'image',
        'options' => array('none' => __('Without Header Element', 'tfuse'), 'slider' => __('Slider on Header', 'tfuse'), 'image' => __('Image on Header', 'tfuse'),'map'=>__('Map on Header', 'tfuse')),
        'type' => 'select',
    ),
    // Quote Before Slider
    array('name' => __('Quote Before Slider', 'tfuse'),
        'desc' => __('Quote Before Slider', 'tfuse'),
        'id' => TF_THEME_PREFIX . '_quote_before_slider',
        'value' => '',
        'type' => 'textarea',
    ),
    // Select Slider
    $this->ext->slider->model->has_sliders() ?
        array(
            'name' => __('Slider', 'tfuse'),
            'desc' => __('Select a slider for your post. The sliders are created on the', 'tfuse') . '<a href="' . admin_url( 'admin.php?page=tf_slider_list' ) . '" target="_blank">' . __('Sliders page', 'tfuse') . '</a>.',
            'id' => TF_THEME_PREFIX . '_select_slider',
            'value' => '',
            'options' => $TFUSE->ext->slider->get_sliders_dropdown(),
            'type' => 'select'
        ) :
        array(
            'name' => __('Slider', 'tfuse'),
            'desc' => '',
            'id' => TF_THEME_PREFIX . '_select_slider',
            'value' => '',
            'html' => __('No sliders created yet. You can start creating one', 'tfuse') . '<a href="' . admin_url('admin.php?page=tf_slider_list') . '">' . __('here', 'tfuse') . '</a>.',
            'type' => 'raw'
        ),
    // Header Image
    array('name' => __('Header Image', 'tfuse'),
        'desc' => __('Upload an image for your header. It will be resized to 870x276 px', 'tfuse'),
        'id' => TF_THEME_PREFIX . '_header_image',
        'value' => '',
        'type' => 'upload',
    ),
    // Image Caption
    array('name' => __('Image Caption', 'tfuse'),
        'desc' => __('Caption for image', 'tfuse'),
        'id' => TF_THEME_PREFIX . '_image_caption',
        'value' => '',
        'type' => 'text',
    ),
    // Link Text
    array('name' => __('Link Text', 'tfuse'),
        'desc' => __('Text for link', 'tfuse'),
        'id' => TF_THEME_PREFIX . '_link_text',
        'value' => '',
        'type' => 'text',
    ),
    // Link Text
    array('name' => __('Link URL', 'tfuse'),
        'desc' => __('URL for link', 'tfuse'),
        'id' => TF_THEME_PREFIX . '_link_url',
        'value' => '',
        'type' => 'text',
    ),
    // Link Target
    array('name' => __('Link Target', 'tfuse'),
        'desc' => __('Target for link', 'tfuse'),
        'id' => TF_THEME_PREFIX . '_link_target',
        'value' => '_self',
        'options' => array('_self' => __('Self', 'tfuse'), '_blank' => __('Blank', 'tfuse')),
        'type' => 'select',
    ),
    // Quote After Image
    array('name' => __('Quote After Image', 'tfuse'),
        'desc' => __('Quote After Image', 'tfuse'),
        'id' => TF_THEME_PREFIX . '_quote_after_image',
        'value' => '',
        'type' => 'textarea',
    ),
    // Map Latitude
    array('name' => __('Latitude', 'tfuse'),
        'desc' => __('Specifies the latitude of the map', 'tfuse'),
        'id' => TF_THEME_PREFIX . '_map_lat',
        'value' => '',
        'type' => 'text',
    ),
    // Map Longitude
    array('name' => __('Longitude', 'tfuse'),
        'desc' => __('Specifies the longitude of the map', 'tfuse'),
        'id' => TF_THEME_PREFIX . '_map_long',
        'value' => '',
        'type' => 'text',
    ),
    // Map Zoom
    array('name' => __('Zoom', 'tfuse'),
        'desc' => __('Specifies the zooming of the map', 'tfuse'),
        'id' => TF_THEME_PREFIX . '_map_zoom',
        'value' => '3',
        'type' => 'text',
    ),
    // Map Type
    array('name' => __('Type', 'tfuse'),
        'desc' => __('Specifies the type of the map', 'tfuse'),
        'id' => TF_THEME_PREFIX . '_map_type',
        'value' => '',
        'options' => array(
            'map1' => '1',
            'map2' => '2',
            'map3' => '3'
        ),
        'type' => 'select'
    ),
    // Map Address
    array('name' => __('Address', 'tfuse'),
        'desc' => __('Specifies the address of the map', 'tfuse'),
        'id' => TF_THEME_PREFIX . '_map_address',
        'value' => '',
        'type' => 'text',
    )
);




?>