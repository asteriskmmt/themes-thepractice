<?php

/**
 * OneByOne slider's configurations
 *
 * @since The Practice 1.0
 */

$options = array(
    'tabs' => array(
        array(
            'name' => __('Slider Settings', 'tfuse'),
            'id' => 'slider_settings', #do no t change this ID
            'headings' => array(
                array(
                    'name' => __('Slider Settings', 'tfuse'),
                    'options' => array(
                        array('name' => __('Slider Title', 'tfuse'),
                            'desc' => __('Change the title of your slider. Only for internal use (Ex: Homepage)', 'tfuse'),
                            'id' => 'slider_title',
                            'value' => '',
                            'type' => 'text',
                            'divider' => true),
                        array(
                            'name' => __('Slider Speed', 'tfuse'),
                            'desc' => __('Set the speed of the sliding animation in milliseconds.', 'tfuse'),
                            'id' => 'slider_slideSpeed',
                            'value' => '700',
                            'type' => 'text',
                            'required' => TRUE
                        ),
                        array(
                            'name' => __('Animation style', 'tfuse'),
                            'desc' => __('Set the easing of the sliding animation.', 'tfuse'),
                            'id' => 'slider_slideEasing',
                            'value' => 'easeInOutExpo',
                            'options' => array('linear' => __('Linear', 'tfuse'), 'swing' => __('Swing', 'tfuse'), 'easeInQuad' => __('EaseInQuad', 'tfuse'), 'easeOutQuad' => __('EaseOutQuad', 'tfuse'),
                                'easeInOutQuad' => __('EaseInOutQuad', 'tfuse'), 'easeInCubic' => __('EaseInCubic', 'tfuse'), 'easeOutCubic' => __('EaseOutCubic', 'tfuse'), 'easeInOutCubic' => __('EaseInOutCubic', 'tfuse'),
                                'easeInQuart' => __('EaseInQuart', 'tfuse'), 'easeOutQuart' => __('EaseOutQuart', 'tfuse'), 'easeInOutQuart' => __('EaseInOutQuart', 'tfuse'), 'easeInQuint' => __('EaseInQuint', 'tfuse'),
                                'easeOutQuint' => __('EaseOutQuint', 'tfuse'), 'easeInOutQuint' => __('EaseInOutQuint', 'tfuse'), 'easeInSine' => __('EaseInSine', 'tfuse'), 'easeOutSine' => __('EaseOutSine', 'tfuse'),
                                'easeInOutSine' => __('EaseInOutSine', 'tfuse'), 'easeInExpo' => __('EaseInExpo', 'tfuse'), 'easeOutExpo' => __('EaseOutExpo', 'tfuse'), 'easeInOutExpo' => __('EaseInOutExpo', 'tfuse'),
                                'easeInCirc' => __('EaseInCirc', 'tfuse'), 'easeOutCirc' => __('EaseOutCirc', 'tfuse'), 'easeInOutCirc' => __('EaseInOutCirc', 'tfuse'), 'easeInElastic' => __('EaseInElastic', 'tfuse'),
                                'easeOutElastic' => __('EaseOutElastic', 'tfuse'), 'easeInOutElastic' => __('EaseInOutElastic', 'tfuse'), 'easeInBack' => __('EaseInBack', 'tfuse'), 'easeOutBack' => __('EaseOutBack', 'tfuse'),
                                'easeInOutBack' => __('EaseInOutBack', 'tfuse'), 'easeInBounce' => __('EaseInBounce', 'tfuse'), 'easeOutBounce' => __('EaseOutBounce', 'tfuse'), 'easeInOutBounce' => __('EaseInOutBounce', 'tfuse') ),
                            'type' => 'select',
                            'required' => TRUE
                        ),
                        array(
                            'name' => __('Randomize', 'tfuse'),
                            'desc' => ' Activate slides randomize.',
                            'id' => 'slider_randomize',
                            'value' => 'false',
                            'type' => 'checkbox',
                            'required' => TRUE
                        ),
                        array(
                            'name' => __('Play', 'tfuse'),
                            'desc' => __('Autoplay slideshow, a positive number will set to true and be the time between slide animation in milliseconds', 'tfuse'),
                            'id' => 'slider_play',
                            'value' => '7000',
                            'type' => 'text',
                            'required' => TRUE
                        ),
                        array(
                            'name' => __('Hover Pause', 'tfuse'),
                            'desc' => __('Activate pause on hover.', 'tfuse'),
                            'id' => 'slider_hoverPause',
                            'value' => 'true',
                            'type' => 'checkbox',
                            'required' => TRUE
                        ),
                        array(
                            'name' => __('Pause', 'tfuse'),
                            'desc' => __('Pause slideshow on click of next/prev or pagination. A positive number will set to true and be the time of pause in milliseconds.', 'tfuse'),
                            'id' => 'slider_pause',
                            'value' => '7000',
                            'type' => 'text',
                            'required' => TRUE
                        ),
                        array('name' => __('Resize images?', 'tfuse'),
                            'desc' => __('Want to let our script to resize the images for you? Or do you want to have total control and upload images with the exact slider image size?', 'tfuse'),
                            'id' => 'slider_image_resize',
                            'value' => 'false',
                            'type' => 'checkbox')
                    )
                )
            )
        ),
        array(
            'name' => __('Add/Edit Slides', 'tfuse'),
            'id' => 'slider_setup', #do not change ID
            'headings' => array(
                array(
                    'name' => __('Add New Slide', 'tfuse'), #do not change
                    'options' => array(
                        array('name' => __('Title', 'tfuse'),
                            'desc' => ' The Title is displayed on the image and will be visible by the users',
                            'id' => 'slide_title',
                            'value' => '',
                            'type' => 'text',
                            'divider' => true),
                        array('name' => __('Link Text', 'tfuse'),
                            'desc' => __('Set the title for the slide link.', 'tfuse'),
                            'id' => 'slide_link_text',
                            'value' => '',
                            'type' => 'text',
                            'divider' => true),
                        array('name' => __('Link URL', 'tfuse'),
                            'desc' => __('Set the slide link URL.', 'tfuse'),
                            'id' => 'slide_link_url',
                            'value' => '',
                            'type' => 'text',
                            'divider' => true),
                        array('name' => __('Link Target', 'tfuse'),
                            'desc' => '',
                            'id' => 'slide_link_target',
                            'value' => '',
                            'options' => array('_self' => __('Self', 'tfuse'), '_blank' => __('Blank', 'tfuse')),
                            'type' => 'select',
                            'divider' => true),
                        // Custom Favicon Option
                        array('name' => __('Image <br />(870px × 440px)', 'tfuse'),
                            'desc' => __('You can upload an image from your hard drive or use one that was already uploaded by pressing  "Insert into Post" button from the image uploader plugin.', 'tfuse'),
                            'id' => 'slide_src',
                            'value' => '',
                            'type' => 'upload',
                            'media' => 'image',
                            'required' => TRUE),
                        //Image Link
                        array('name' => __('Image link', 'tfuse'),
                            'desc' => __('Set the image link.', 'tfuse'),
                            'id' => 'slide_url',
                            'value' => '',
                            'type' => 'text',
                           )
                    )
                )
            )
        ),
        array(
            'name' => __('Category Setup', 'tfuse'),
            'id' => 'slider_type_categories',
            'headings' => array(
                array(
                    'name' => __('Category options', 'tfuse'),
                    'options' => array(
                        array(
                            'name' => __('Select specific categories', 'tfuse'),
                            'desc' => __('Pick one or more
categories by starting to type the category name. If you leave blank the slider will fetch images
from all <a target="_new" href="', 'tfuse') . get_admin_url() . 'edit-tags.php?taxonomy=category">Categories</a>.',
                            'id' => 'categories_select',
                            'type' => 'multi',
                            'subtype' => 'category'
                        ),
                        array(
                            'name' => __('Number of images in the slider', 'tfuse'),
                            'desc' => __('How many images do you want in the slider?', 'tfuse'),
                            'id' => 'sliders_posts_number',
                            'value' => 6,
                            'type' => 'text'
                        )
                    )
                )
            )
        ),
        array(
            'name' => __('Posts Setup', 'tfuse'),
            'id' => 'slider_type_posts',
            'headings' => array(
                array(
                    'name' => __('Posts options', 'tfuse'),
                    'options' => array(
                        array(
                            'name' => __('Select specific Posts', 'tfuse'),
                            'desc' => __('Pick one or more <a target="_new" href="', 'tfuse') . get_admin_url() . 'edit.php">posts</a> by starting to type the Post name. The slider will be populated with images from the posts
you selected.',
                            'id' => 'posts_select',
                            'type' => 'multi',
                            'subtype' => 'post'
                        )
                    )
                )
            )
        ),
        array(
            'name' => __('Tags Setup', 'tfuse'),
            'id' => 'slider_type_tags',
            'headings' => array(
                array(
                    'name' => __('Tags options', 'tfuse'),
                    'options' => array(
                        array(
                            'name' => __('Select specific tags', 'tfuse'),
                            'desc' => __('Pick one or more <a target="_new" href="', 'tfuse') . get_admin_url() . 'edit-tags.php?taxonomy=post_tag">tags</a> by starting to type the tag name. The slider will be populated with images from posts
that have the selected tags.',
                            'id' => 'tags_select',
                            'type' => 'multi',
                            'subtype' => 'post_tag'
                        )
                    )
                )
            )
        )
    )
);
$options['extra_options'] = array();
?>