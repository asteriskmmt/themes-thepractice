
-----------------------------
Step by Step Install Tutorial
-----------------------------

http://docs.themefuse.com/?article=theme-related/how-do-i-install-one-of-your-wordpress-themes


---------------
Very Important!
---------------

After you've uploaded the theme on your server it is important to use (activate) the child theme. 
This will enable you to make any modifications to the theme and not lose them when you'll 
get a future update to the main theme. 

More on child themes can be found here: http://docs.themefuse.com/?article=theme-related/use-the-child-theme


-------------------------
Get Hosting & Free Domain
-------------------------

You can upgrade this theme with the optimized hosting pack (that comes with a free domain name), 
and we’ll take care of all the set up, install WordPress and the theme it self and you'll receive 
the credentials to your website in a matter of minutes. The website will look exact like the one you 
see on our live preview demo.

More on this can be found here: http://themefuse.com/hosting-domain/


-------------
Documentation
-------------

http://docs.themefuse.com/


---------
Help Desk
---------

http://support.themefuse.com/hc/en-us/requests/new


-----------
Custom Work
-----------

Some WordPress professionals, that are familiar with our themes are will love to help if available

http://themefuse.com/custom-work/

