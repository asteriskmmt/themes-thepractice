<div class="wrap">
    <?php screen_icon('tools'); ?>
    <h2><?php _e('ThemeFuse Updates', 'tfuse'); ?></h2>
</div>