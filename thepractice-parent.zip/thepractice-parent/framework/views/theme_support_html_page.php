<div id="tfuse_fields" class="wrap metabox-holder">
<?php $this->interface->page_header_info(); ?>

<br />
<div class="support" style="text-align: center;">
    <iframe src="http://themefuse.com/pages/support.html" width="746" height="351" scrolling="no" frameBorder="0"></iframe>
</div>

<div class="tfclear"></div>
</div>