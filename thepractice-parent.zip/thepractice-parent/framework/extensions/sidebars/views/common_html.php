<?php wp_nonce_field('closedpostboxes', 'closedpostboxesnonce', false) ?>
<?php wp_nonce_field('meta-box-order', 'meta-box-order-nonce', false) ?>
<div id="tfuse_fields" class="wrap metabox-holder">

    <?php $this->interface->page_header_info(); ?>

    <div style="clear:both;height:20px;">&nbsp</div>