<?php if ( ! defined( 'ABSPATH' ) ) {
	die( 'Direct access forbidden.' );
}

class JSMin_UnterminatedRegExpException extends Exception {}