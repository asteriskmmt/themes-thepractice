<div value="<?php echo $slider_design; ?>" class="selectable_option slider_image_preview" preview="<?php echo tf_config_extimage($ext_name . '/designs/' . $slider_design, 'preview.jpg') ?>">
    <div class="over_thumb selected"></div>
    <img src="<?php echo tf_config_extimage($ext_name . '/designs/' . $slider_design, 'preview_small.jpg') ?>" border="0" />
</div>