<?php
tf_do_placeholder('blue');
